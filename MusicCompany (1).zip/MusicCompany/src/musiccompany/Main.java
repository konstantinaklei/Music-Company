package musiccompany;



import javax.swing.table.DefaultTableModel;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import java.sql.CallableStatement;


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author user
 */


    
    public class Main extends javax.swing.JFrame {

    /**
     * Creates new form Main
     */
    public Main(int tabn) {
        initComponents();
        
        this.setLocationRelativeTo(null);
        
        loadAlbumsIntoCombo(AlbumBox);
        loadArtistsIntoCombo(ArtistBox);
        loadGenresIntoCombo(GenreBox);
        loadArtistsIntoCombo(ArtistAlBox);
        loadGenresIntoCombo(GenreAlBox);
        
        
        DefaultTableModel artistModel = new DefaultTableModel();
        ArtTable.setModel(artistModel);
        artistModel.setColumnIdentifiers(new Object[]{"Artist Name", "Songs", "Albums", "Producer", "Manager"});
        
        DefaultTableModel sonModel = new DefaultTableModel();
        SonTable.setModel(sonModel);
        sonModel.setColumnIdentifiers(new Object[]{"ID", "Song", "Duration(seconds)", "Artist", "Album", "Genre"});


        DefaultTableModel AlbModel = new DefaultTableModel();
        AlbTable.setModel(AlbModel);
        AlbModel.setColumnIdentifiers(new Object[]{"ID","Album","song number","total duration","genre","Artist"});
        
        DefaultTableModel ProModel = new DefaultTableModel();
        ProTable.setModel(ProModel);
        ProModel.setColumnIdentifiers(new Object[]{"Producer","Company", "Song Number"});
        
        DefaultTableModel ManModel = new DefaultTableModel();
        ManTable.setModel(ManModel);
        ManModel.setColumnIdentifiers(new Object[]{"Manager","Phone number", "email","Artist number","Producer Number"});  
        
        LoadArt();
        LoadSon();
        SonTable.getColumnModel().getColumn(0).setMinWidth(0);
        SonTable.getColumnModel().getColumn(0).setMaxWidth(0);
        SonTable.getColumnModel().getColumn(0).setWidth(0);
        LoadAlb();
        AlbTable.getColumnModel().getColumn(0).setMinWidth(0);
        AlbTable.getColumnModel().getColumn(0).setMaxWidth(0);
        AlbTable.getColumnModel().getColumn(0).setWidth(0);
        LoadMan();
        LoadProd();
        TabbedPane.setSelectedIndex(tabn);
    }
    

    private static final String URL = "jdbc:postgresql://dblabs.iee.ihu.gr:5432/athikoto";
    private static final String USER = "athikoto";
    private static final String PASSWORD = "1924ak"; 

    private int currentEditingSongId = -1; 
   

    
    
    private int getIdFromName(String tableName, String nameColumn, String idColumn, String name) {
    
        String sql = "SELECT " + idColumn + " FROM " + tableName + " WHERE " + nameColumn + " = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, name);
            ResultSet rs = ps.executeQuery();
        
            if (rs.next()) {
                return rs.getInt(idColumn);
            }
            return -1; // Not found
        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }

    private void setComboSelection(JComboBox<ComboItem> combo, int id) {
        for (int i = 0; i < combo.getItemCount(); i++) {
            ComboItem item = combo.getItemAt(i);
            if (item.getId() == id) {
                combo.setSelectedIndex(i);
                return;
            }
        }
    }

    private boolean exists(String sql, Object value) {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setObject(1, value);
            ResultSet rs = ps.executeQuery();

            return rs.next();

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    private boolean albumMatchesArtist(int albumId, int artistId) {
        String sql = "SELECT 1 FROM albums WHERE album_id = ? AND artist_id = ?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, albumId);
            ps.setInt(2, artistId);
            ResultSet rs = ps.executeQuery();

            return rs.next();

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    private void updateSongInternal(int trackId, String newName, int newDuration, int newArtistId, int newAlbumId, String newGenre) {
        if (!exists("SELECT 1 FROM artists WHERE artist_id = ?", newArtistId)) {
            JOptionPane.showMessageDialog(this, "Artist does not exist!", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (!exists("SELECT 1 FROM albums WHERE album_id = ?", newAlbumId)) {
            JOptionPane.showMessageDialog(this, "Album does not exist!", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (!albumMatchesArtist(newAlbumId, newArtistId)) {
            JOptionPane.showMessageDialog(this, 
                "This album does not belong to the selected artist!", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String sql_call = "CALL update_song(?, ?, ?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);

             CallableStatement cs = conn.prepareCall(sql_call)) { 

            cs.setInt(1, trackId);
            cs.setString(2, newName);
            cs.setInt(3, newDuration);
            cs.setInt(4, newArtistId); 
            cs.setInt(5, newAlbumId); 
            cs.setString(6, newGenre);

            cs.execute(); 

            JOptionPane.showMessageDialog(this, "Song updated successfully!");
            LoadSon();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();

        }
    }

    
    

    
    
    private void LoadArt() {
        System.out.println("loadArtists() started!");

        DefaultTableModel model = (DefaultTableModel) ArtTable.getModel();
        model.setRowCount(0);

        try {
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Connected to database!");

            String sql = "SELECT * FROM load_artists()";


            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            System.out.println("Query executed!");

            boolean found = false;

            while (rs.next()) {

                found = true;
                System.out.println("Loading artist: " + rs.getString("artist_name"));

                model.addRow(new Object[]{
                    rs.getString("artist_name"),
                    rs.getInt("number_of_songs"),
                    rs.getInt("number_of_albums"),
                    rs.getString("producer_name"),
                    rs.getString("manager_name")
                });
            }

            if (!found) {
                System.out.println("NO DATA FOUND in artist table!");
            }

            conn.close();

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void LoadSon() {
        System.out.println("LoadSon() started!");

        DefaultTableModel model = (DefaultTableModel) SonTable.getModel();
        model.setRowCount(0);

        try {
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);

            String sql = "SELECT * FROM load_songs()";


            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            boolean found = false;

            while(rs.next()) {
                found = true;
                model.addRow(new Object[] {
                    rs.getInt("track_id"),          
                    rs.getString("song_name"),       
                    rs.getInt("duration"),            
                    rs.getString("artist_name"),    
                    rs.getString("album_name"),       
                    rs.getString("genre")              
                });
            }

            if (!found) {
                System.out.println("NO DATA FOUND in songs!");
            }

            conn.close();

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void LoadAlb() {
        System.out.println("LoadAlbums() started!");

        DefaultTableModel model = (DefaultTableModel) AlbTable.getModel();
        model.setRowCount(0);

        try {
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);

            String sql = "SELECT * FROM load_albums()";

            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            boolean found = false;

            while(rs.next()) {
                found = true;

                model.addRow(new Object[]{
                    rs.getInt("album_id"),
                    rs.getString("album_name"),
                    rs.getInt("song_number"),
                    rs.getString("formatted_total_duration"),
                    rs.getString("genre"),
                    rs.getString("artist_name")
                });
            }

            if (!found) {
                System.out.println("NO DATA FOUND in albums!");
            }

            conn.close();

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
   
    private void LoadProd() {
        System.out.println("LoadProducer() started!");

        DefaultTableModel model = (DefaultTableModel) ProTable.getModel();
        model.setRowCount(0);

        try {
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);

            String sql = "SELECT * FROM load_producers()";
            
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            boolean found = false;

            while (rs.next()) {
                found = true;

                model.addRow(new Object[] {
                    rs.getString("producer_name"),
                    rs.getString("company_name"),
                    rs.getInt("song_number")
                });
            }

            if (!found) {
                System.out.println("NO DATA FOUND in producer table!");
            }

            conn.close();

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void LoadMan() {
        System.out.println("LoadManager() started!");

        DefaultTableModel model = (DefaultTableModel) ManTable.getModel();
        model.setRowCount(0);

        try {
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);

            String sql = "SELECT * FROM load_managers()";

            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            boolean found = false;

            while (rs.next()) {
                found = true;

                model.addRow(new Object[] {
                    rs.getString("manager_name"),
                    rs.getString("phone_number"),
                    rs.getString("email"),
                    rs.getInt("number_of_artists"),
                    rs.getInt("number_of_producers")
                });
            }

            if (!found) {
                System.out.println("NO DATA FOUND in manager table!");
            }

            conn.close();

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
}


    
    private void deleteAlbum(){
        int row = AlbTable.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Please select an album to delete.");
            return;
        }

        String trackStr = String.valueOf(AlbTable.getValueAt(row, 0));

        int albumId;
        try {
            albumId = Integer.parseInt(trackStr);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Invalid track ID in table.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to delete Album ID: " + albumId +"album name"+ "?",
                "Confirm Delete",
                JOptionPane.YES_NO_OPTION
        );

        if (confirm != JOptionPane.YES_OPTION)return;

        if (confirm != JOptionPane.YES_OPTION) return;

        String sql_call = "CALL delete_album(?)"; 

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            CallableStatement cs = conn.prepareCall(sql_call)) { 
            cs.setInt(1, albumId);
            cs.execute(); 

            JOptionPane.showMessageDialog(this, "Album deleted successfully!");
            LoadAlb();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
            e.printStackTrace();
        }

            Object val = SonTable.getValueAt(row, 0);
            System.out.println("DEBUG ID VALUE = [" + val + "] , TYPE = " + val.getClass().getName());

    }
    
    private void deleteSong() {
        int row = SonTable.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Please select a song to delete.");
            return;
        }

        String trackStr = String.valueOf(SonTable.getValueAt(row, 0));

        int trackId;
        try {
            trackId = Integer.parseInt(trackStr);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Invalid track ID in table.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to delete song ID: " + trackId +"song name"+ "?",
                "Confirm Delete",
                JOptionPane.YES_NO_OPTION
        );

        if (confirm != JOptionPane.YES_OPTION)return;

        if (confirm != JOptionPane.YES_OPTION) return;

        String sql_call = "CALL delete_song(?)"; 

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            CallableStatement cs = conn.prepareCall(sql_call)) { 
            cs.setInt(1, trackId);
            cs.execute(); 

            JOptionPane.showMessageDialog(this, "Song deleted successfully!");
            LoadSon();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
            e.printStackTrace();
        }

            Object val = SonTable.getValueAt(row, 0);
            System.out.println("DEBUG ID VALUE = [" + val + "] , TYPE = " + val.getClass().getName());

    }

    private void addSong(String title, int duration, int albumId, int artistId, String genre) {
  
        String sql_call = "CALL add_song(?, ?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
         
             CallableStatement cs = conn.prepareCall(sql_call)) { 

            cs.setString(1, title);
            cs.setInt(2, duration);
            cs.setInt(3, artistId); 
            cs.setInt(4, albumId); 
            cs.setString(5, genre);

            cs.execute(); 

            JOptionPane.showMessageDialog(this, "Song added successfully!");
            LoadSon();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error adding song: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void editSong() {
        int row = SonTable.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Please select a song to edit.", "No Song Selected", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String trackIdStr = String.valueOf(SonTable.getValueAt(row, 0));
        String oldName = String.valueOf(SonTable.getValueAt(row, 1));
        String oldDurationStr = String.valueOf(SonTable.getValueAt(row, 2));
        String oldArtistName = String.valueOf(SonTable.getValueAt(row, 3)); 
        String oldAlbumName = String.valueOf(SonTable.getValueAt(row, 4));  
        String oldGenre = String.valueOf(SonTable.getValueAt(row, 5));

        int oldArtistId = getIdFromName("artists", "artist_name", "artist_id", oldArtistName);
        int oldAlbumId = getIdFromName("albums", "album_name", "album_id", oldAlbumName);

        if (oldArtistId == -1 || oldAlbumId == -1) {
            JOptionPane.showMessageDialog(this, "Error retrieving data IDs for selected song.", "Database Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        SongNameText.setText(oldName);
        DurationText.setText(oldDurationStr);

        GenreBox.setSelectedItem(oldGenre);

        setComboSelection(ArtistBox, oldArtistId);

        setComboSelection(AlbumBox, oldAlbumId);

        currentEditingSongId = Integer.parseInt(trackIdStr); 

        AddSongDialog.setTitle("Edit Song: " + oldName);


        AddSongDialog.pack();
        AddSongDialog.setLocationRelativeTo(this); // Center relative to Main window
        AddSongDialog.setVisible(true);
    }
    
    
    
    
    private void loadAlbumsIntoCombo(JComboBox<ComboItem> combo) {
       
        combo.removeAllItems();

        String sql = "SELECT album_id, album_name FROM albums ORDER BY album_name";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                combo.addItem(new ComboItem(
                    rs.getInt("album_id"),
                    rs.getString("album_name")
                ));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadArtistsIntoCombo(JComboBox<ComboItem> combo) {
        combo.removeAllItems();

        String sql = "SELECT artist_id, artist_name FROM artists ORDER BY artist_name";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                combo.addItem(new ComboItem(
                    rs.getInt("artist_id"),
                    rs.getString("artist_name")
                ));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadGenresIntoCombo(JComboBox<String> combo) {
        combo.removeAllItems();

        String sql = "SELECT DISTINCT genre FROM songs WHERE genre IS NOT NULL ORDER BY genre";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                combo.addItem(rs.getString("genre"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

     
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        AddSongDialog = new javax.swing.JDialog();
        jPanel6 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        SongNameText = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        DurationText = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        GenreBox = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        AlbumBox = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        ArtistBox = new javax.swing.JComboBox<>();
        OkDialogB = new javax.swing.JButton();
        CancelDialogB = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        AddAlbumDialog = new javax.swing.JDialog();
        jPanel8 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        AlbumNameText = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        ArtistAlBox = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        GenreAlBox = new javax.swing.JComboBox<>();
        OkAlbumB = new javax.swing.JButton();
        CancelAlbumB = new javax.swing.JButton();
        TabbedPane = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        ArtTable = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        AddSongB = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        SonTable = new javax.swing.JTable();
        EditSongB = new javax.swing.JButton();
        DeleteSongB = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        AlbTable = new javax.swing.JTable();
        AddAlbumB = new javax.swing.JButton();
        DeleteAlbumB = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        ProTable = new javax.swing.JTable();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        ManTable = new javax.swing.JTable();

        jPanel6.setBackground(new java.awt.Color(165, 162, 225));
        jPanel6.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 51, 255), 2, true));

        jLabel1.setForeground(new java.awt.Color(0, 0, 102));
        jLabel1.setText("Song Name:");

        SongNameText.setForeground(new java.awt.Color(102, 51, 255));

        jLabel2.setForeground(new java.awt.Color(0, 0, 102));
        jLabel2.setText("Duration (seconds):");

        DurationText.setForeground(new java.awt.Color(102, 51, 255));

        jLabel3.setForeground(new java.awt.Color(0, 0, 102));
        jLabel3.setText("Genre:");

        GenreBox.setBackground(new java.awt.Color(102, 51, 255));
        GenreBox.setForeground(new java.awt.Color(153, 153, 255));
        GenreBox.setModel(new javax.swing.DefaultComboBoxModel<>());

        jLabel4.setForeground(new java.awt.Color(0, 0, 102));
        jLabel4.setText("Album:");

        AlbumBox.setBackground(new java.awt.Color(102, 51, 255));
        AlbumBox.setForeground(new java.awt.Color(165, 162, 225));
        AlbumBox.setModel(new javax.swing.DefaultComboBoxModel<>());

        jLabel5.setForeground(new java.awt.Color(0, 0, 102));
        jLabel5.setText("Artist:");

        ArtistBox.setBackground(new java.awt.Color(102, 51, 255));
        ArtistBox.setForeground(new java.awt.Color(165, 162, 225));
        ArtistBox.setModel(new javax.swing.DefaultComboBoxModel<>());

        OkDialogB.setForeground(new java.awt.Color(102, 51, 255));
        OkDialogB.setText("ok");
        OkDialogB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OkDialogBActionPerformed(evt);
            }
        });

        CancelDialogB.setForeground(new java.awt.Color(102, 51, 255));
        CancelDialogB.setText("cancel");
        CancelDialogB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelDialogBActionPerformed(evt);
            }
        });

        jButton1.setForeground(new java.awt.Color(102, 51, 255));
        jButton1.setText("Add Album");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(CancelDialogB)
                .addGap(18, 18, 18)
                .addComponent(OkDialogB)
                .addGap(20, 20, 20))
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(2, 2, 2)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(SongNameText, javax.swing.GroupLayout.DEFAULT_SIZE, 263, Short.MAX_VALUE)
                                .addComponent(DurationText)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton1))
                    .addComponent(jLabel1)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel5))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(GenreBox, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(ArtistBox, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(AlbumBox, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(37, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(SongNameText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(DurationText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(GenreBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(15, 15, 15)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(ArtistBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton1)
                            .addComponent(AlbumBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addContainerGap(57, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(CancelDialogB)
                            .addComponent(OkDialogB))
                        .addContainerGap())))
        );

        javax.swing.GroupLayout AddSongDialogLayout = new javax.swing.GroupLayout(AddSongDialog.getContentPane());
        AddSongDialog.getContentPane().setLayout(AddSongDialogLayout);
        AddSongDialogLayout.setHorizontalGroup(
            AddSongDialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(AddSongDialogLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        AddSongDialogLayout.setVerticalGroup(
            AddSongDialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel8.setBackground(new java.awt.Color(165, 162, 225));
        jPanel8.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 51, 255), 2, true));

        jLabel6.setForeground(new java.awt.Color(0, 0, 102));
        jLabel6.setText("Album Name:");

        AlbumNameText.setForeground(new java.awt.Color(102, 51, 255));

        jLabel7.setForeground(new java.awt.Color(0, 0, 102));
        jLabel7.setText("Artist:");

        ArtistAlBox.setBackground(new java.awt.Color(102, 51, 255));
        ArtistAlBox.setModel(new javax.swing.DefaultComboBoxModel<>());

        jLabel8.setForeground(new java.awt.Color(0, 0, 102));
        jLabel8.setText("Genre");

        GenreAlBox.setBackground(new java.awt.Color(102, 51, 255));
        GenreAlBox.setModel(new javax.swing.DefaultComboBoxModel<>());

        OkAlbumB.setForeground(new java.awt.Color(102, 51, 255));
        OkAlbumB.setText("ok");
        OkAlbumB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OkAlbumBActionPerformed(evt);
            }
        });

        CancelAlbumB.setForeground(new java.awt.Color(102, 51, 255));
        CancelAlbumB.setText("cancel");
        CancelAlbumB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelAlbumBActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel6)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap(22, Short.MAX_VALUE)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8)
                    .addComponent(jLabel7)
                    .addComponent(AlbumNameText, javax.swing.GroupLayout.PREFERRED_SIZE, 314, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(GenreAlBox, javax.swing.GroupLayout.Alignment.LEADING, 0, 126, Short.MAX_VALUE)
                        .addComponent(ArtistAlBox, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap(48, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(CancelAlbumB)
                .addGap(18, 18, 18)
                .addComponent(OkAlbumB)
                .addContainerGap())
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(AlbumNameText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ArtistAlBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(GenreAlBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 61, Short.MAX_VALUE)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(OkAlbumB)
                    .addComponent(CancelAlbumB))
                .addContainerGap())
        );

        javax.swing.GroupLayout AddAlbumDialogLayout = new javax.swing.GroupLayout(AddAlbumDialog.getContentPane());
        AddAlbumDialog.getContentPane().setLayout(AddAlbumDialogLayout);
        AddAlbumDialogLayout.setHorizontalGroup(
            AddAlbumDialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(AddAlbumDialogLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        AddAlbumDialogLayout.setVerticalGroup(
            AddAlbumDialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(AddAlbumDialogLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("MusicCompany");
        setBackground(new java.awt.Color(165, 162, 225));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setResizable(false);

        TabbedPane.setBackground(new java.awt.Color(0, 0, 102));
        TabbedPane.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, java.awt.Color.white, null, java.awt.Color.white));
        TabbedPane.setForeground(new java.awt.Color(165, 162, 225));
        TabbedPane.setTabPlacement(javax.swing.JTabbedPane.LEFT);
        TabbedPane.setAlignmentX(10.0F);
        TabbedPane.setAlignmentY(10.0F);
        TabbedPane.setBounds(new java.awt.Rectangle(5, 5, 5, 5));
        TabbedPane.setFont(new java.awt.Font("Hiragino Maru Gothic ProN", 3, 15)); // NOI18N
        TabbedPane.setOpaque(true);

        jPanel1.setBackground(new java.awt.Color(165, 162, 225));
        jPanel1.setForeground(new java.awt.Color(0, 0, 102));

        ArtTable.setBackground(new java.awt.Color(204, 204, 255));
        ArtTable.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        ArtTable.setForeground(new java.awt.Color(0, 0, 102));
        ArtTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        ArtTable.setGridColor(new java.awt.Color(165, 162, 225));
        ArtTable.setName("artists"); // NOI18N
        ArtTable.setRowHeight(25);
        ArtTable.setSelectionBackground(new java.awt.Color(165, 162, 225));
        ArtTable.setSelectionForeground(new java.awt.Color(0, 0, 102));
        ArtTable.setShowGrid(true);
        ArtTable.setShowVerticalLines(true);
        jScrollPane1.setViewportView(ArtTable);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 579, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(30, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(32, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 368, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30))
        );

        TabbedPane.addTab("Artists", jPanel1);

        jPanel2.setBackground(new java.awt.Color(165, 162, 225));
        jPanel2.setForeground(new java.awt.Color(0, 0, 102));

        AddSongB.setForeground(new java.awt.Color(102, 51, 255));
        AddSongB.setText("Add Song");
        AddSongB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddSongBActionPerformed(evt);
            }
        });

        SonTable.setBackground(new java.awt.Color(204, 204, 255));
        SonTable.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        SonTable.setForeground(new java.awt.Color(0, 0, 102));
        SonTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        SonTable.setGridColor(new java.awt.Color(165, 162, 225));
        SonTable.setRowHeight(25);
        SonTable.setRowMargin(3);
        SonTable.setSelectionBackground(new java.awt.Color(165, 162, 225));
        SonTable.setSelectionForeground(new java.awt.Color(0, 0, 102));
        SonTable.setShowGrid(true);
        SonTable.setSurrendersFocusOnKeystroke(true);
        jScrollPane3.setViewportView(SonTable);

        EditSongB.setForeground(new java.awt.Color(102, 51, 255));
        EditSongB.setText("Edit Song");
        EditSongB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditSongBActionPerformed(evt);
            }
        });

        DeleteSongB.setForeground(new java.awt.Color(102, 51, 255));
        DeleteSongB.setText("Delete Song");
        DeleteSongB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteSongBActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(AddSongB, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(133, 133, 133)
                .addComponent(EditSongB)
                .addGap(118, 118, 118)
                .addComponent(DeleteSongB)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(25, Short.MAX_VALUE)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 590, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(AddSongB)
                    .addComponent(EditSongB)
                    .addComponent(DeleteSongB))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 333, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(39, Short.MAX_VALUE))
        );

        TabbedPane.addTab("Songs", jPanel2);

        jPanel3.setBackground(new java.awt.Color(165, 162, 225));
        jPanel3.setForeground(new java.awt.Color(0, 0, 102));

        AlbTable.setBackground(new java.awt.Color(204, 204, 255));
        AlbTable.setForeground(new java.awt.Color(0, 0, 102));
        AlbTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        AlbTable.setGridColor(new java.awt.Color(165, 162, 225));
        AlbTable.setRowHeight(25);
        AlbTable.setSelectionBackground(new java.awt.Color(165, 162, 225));
        AlbTable.setSelectionForeground(new java.awt.Color(0, 0, 102));
        AlbTable.setShowGrid(true);
        AlbTable.setShowHorizontalLines(true);
        AlbTable.setShowVerticalLines(true);
        jScrollPane2.setViewportView(AlbTable);

        AddAlbumB.setForeground(new java.awt.Color(102, 51, 255));
        AddAlbumB.setText("Add Album");
        AddAlbumB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddAlbumBActionPerformed(evt);
            }
        });

        DeleteAlbumB.setForeground(new java.awt.Color(102, 51, 255));
        DeleteAlbumB.setText("Delete Album");
        DeleteAlbumB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteAlbumBActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 561, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(47, Short.MAX_VALUE))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addComponent(AddAlbumB)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(DeleteAlbumB)
                .addGap(65, 65, 65))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(AddAlbumB)
                    .addComponent(DeleteAlbumB))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 341, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(29, Short.MAX_VALUE))
        );

        TabbedPane.addTab("Albums", jPanel3);

        jPanel4.setBackground(new java.awt.Color(165, 162, 225));
        jPanel4.setForeground(new java.awt.Color(0, 0, 102));

        ProTable.setBackground(new java.awt.Color(204, 204, 255));
        ProTable.setForeground(new java.awt.Color(0, 0, 102));
        ProTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        ProTable.setGridColor(new java.awt.Color(165, 162, 225));
        ProTable.setRowHeight(25);
        ProTable.setRowMargin(5);
        ProTable.setSelectionBackground(new java.awt.Color(165, 162, 225));
        ProTable.setSelectionForeground(new java.awt.Color(0, 0, 102));
        ProTable.setShowGrid(true);
        ProTable.setShowHorizontalLines(true);
        ProTable.setShowVerticalLines(true);
        jScrollPane4.setViewportView(ProTable);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 563, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(45, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 375, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        TabbedPane.addTab("Producer", jPanel4);

        jPanel5.setBackground(new java.awt.Color(165, 162, 225));
        jPanel5.setForeground(new java.awt.Color(0, 0, 102));

        ManTable.setBackground(new java.awt.Color(204, 204, 255));
        ManTable.setForeground(new java.awt.Color(0, 0, 102));
        ManTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        ManTable.setGridColor(new java.awt.Color(165, 162, 225));
        ManTable.setRowHeight(25);
        ManTable.setRowMargin(5);
        ManTable.setSelectionBackground(new java.awt.Color(165, 162, 225));
        ManTable.setSelectionForeground(new java.awt.Color(0, 0, 102));
        ManTable.setShowGrid(true);
        jScrollPane5.setViewportView(ManTable);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 559, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(60, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 377, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(18, Short.MAX_VALUE))
        );

        TabbedPane.addTab("Manager", jPanel5);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(TabbedPane))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(TabbedPane)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void OkDialogBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OkDialogBActionPerformed
        String title = SongNameText.getText();
    
        int duration;
        try {
            duration = Integer.parseInt(DurationText.getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Duration must be a valid number.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
    
        String genre = (String) GenreBox.getSelectedItem();

        ComboItem albumItem = (ComboItem) AlbumBox.getSelectedItem();
        ComboItem artistItem = (ComboItem) ArtistBox.getSelectedItem();

        if (albumItem == null || artistItem == null || title.isEmpty() || genre == null) {
             JOptionPane.showMessageDialog(this, "Please fill all fields.", "Input Error", JOptionPane.ERROR_MESSAGE);
             return;
        }

        int albumId = albumItem.getId();
        int artistId = artistItem.getId();

        if (currentEditingSongId == -1) {
            addSong(title, duration, albumId, artistId, genre);
        } else {
            updateSongInternal(currentEditingSongId, title, duration, artistId, albumId, genre);

        }

        currentEditingSongId = -1; 
        AddSongDialog.setTitle("Add Song");
        SongNameText.setText("");
        DurationText.setText("");

        AddSongDialog.dispose();
    }//GEN-LAST:event_OkDialogBActionPerformed

    private void CancelDialogBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelDialogBActionPerformed
        currentEditingSongId = -1; 
        AddSongDialog.setTitle("Add Song");
        SongNameText.setText("");
        DurationText.setText("");
        AddSongDialog.dispose();
    }//GEN-LAST:event_CancelDialogBActionPerformed

    private void OkAlbumBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OkAlbumBActionPerformed
        String AlName = AlbumNameText.getText();
        String Algenre = (String) GenreAlBox.getSelectedItem();
        
        if (AlName.trim().isEmpty() || Algenre == null || ArtistAlBox.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Please fill out the Album Name, Artist, and Genre.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int artistId = ((ComboItem)ArtistAlBox.getSelectedItem()).getId();

        String sql_call = "CALL add_album(?, ?, ?)"; 
        
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             CallableStatement cs = conn.prepareCall(sql_call)) { 
             
            cs.setString(1, AlName);     
            cs.setInt(2, artistId);       
            cs.setString(3, Algenre);    

            cs.execute(); 
            
            JOptionPane.showMessageDialog(this, "Album added successfully!");
            
            loadAlbumsIntoCombo(AlbumBox);
            LoadAlb(); 
            
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error adding album: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
        
        AlbumNameText.setText("");

        loadAlbumsIntoCombo(AlbumBox);
        LoadAlb();
        AddAlbumDialog.dispose();
    }//GEN-LAST:event_OkAlbumBActionPerformed

    private void CancelAlbumBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelAlbumBActionPerformed
        AddAlbumDialog.dispose();
    }//GEN-LAST:event_CancelAlbumBActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        AddAlbumDialog.pack(); 
        AddAlbumDialog.setLocationRelativeTo(this);
        AddAlbumDialog.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void AddAlbumBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddAlbumBActionPerformed
        AddAlbumDialog.pack(); 
        AddAlbumDialog.setLocationRelativeTo(this);
        AddAlbumDialog.setVisible(true);
    }//GEN-LAST:event_AddAlbumBActionPerformed

    private void DeleteSongBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteSongBActionPerformed
        deleteSong();
    }//GEN-LAST:event_DeleteSongBActionPerformed

    private void EditSongBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditSongBActionPerformed
        editSong();
    }//GEN-LAST:event_EditSongBActionPerformed

    private void AddSongBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddSongBActionPerformed
        currentEditingSongId = -1;
        SongNameText.setText("");
        DurationText.setText("");
        GenreBox.setSelectedIndex(0);
        ArtistBox.setSelectedIndex(0);
        AlbumBox.setSelectedIndex(0);

        AddSongDialog.pack(); 
        AddSongDialog.setLocationRelativeTo(this);
        AddSongDialog.setVisible(true);
    }//GEN-LAST:event_AddSongBActionPerformed

    private void DeleteAlbumBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteAlbumBActionPerformed
        deleteAlbum();
    }//GEN-LAST:event_DeleteAlbumBActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Main(0).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AddAlbumB;
    private javax.swing.JDialog AddAlbumDialog;
    private javax.swing.JButton AddSongB;
    private javax.swing.JDialog AddSongDialog;
    private javax.swing.JTable AlbTable;
    private javax.swing.JComboBox<ComboItem> AlbumBox;
    private javax.swing.JTextField AlbumNameText;
    private javax.swing.JTable ArtTable;
    private javax.swing.JComboBox<ComboItem> ArtistAlBox;
    private javax.swing.JComboBox<ComboItem> ArtistBox;
    private javax.swing.JButton CancelAlbumB;
    private javax.swing.JButton CancelDialogB;
    private javax.swing.JButton DeleteAlbumB;
    private javax.swing.JButton DeleteSongB;
    private javax.swing.JTextField DurationText;
    private javax.swing.JButton EditSongB;
    private javax.swing.JComboBox<String> GenreAlBox;
    private javax.swing.JComboBox<String> GenreBox;
    private javax.swing.JTable ManTable;
    private javax.swing.JButton OkAlbumB;
    private javax.swing.JButton OkDialogB;
    private javax.swing.JTable ProTable;
    private javax.swing.JTable SonTable;
    private javax.swing.JTextField SongNameText;
    private javax.swing.JTabbedPane TabbedPane;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    // End of variables declaration//GEN-END:variables
}
